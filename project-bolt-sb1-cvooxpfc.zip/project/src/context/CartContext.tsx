import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { CartItem, Product, Currency, ExchangeRates } from '../types';

interface CartContextType {
  items: (CartItem & { product: Product })[];
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  rates: ExchangeRates;
  loading: boolean;
  addToCart: (product: Product, quantity?: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  totalItems: number;
  subtotalUsd: number;
  convertPrice: (priceUsd: number) => number;
  formatPrice: (priceUsd: number) => string;
  sessionId: string;
}

const CartContext = createContext<CartContextType | null>(null);

const EXCHANGE_RATES: ExchangeRates = {
  USD: 1,
  ZAR: 18.50,
  ZMW: 26.50,
  BWP: 13.50,
};

const CURRENCY_SYMBOLS_MAP: Record<Currency, string> = {
  USD: '$',
  ZAR: 'R',
  ZMW: 'K',
  BWP: 'P',
};

function generateSessionId(): string {
  return 'session_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
}

function getSessionId(): string {
  const stored = sessionStorage.getItem('mageba_session_id');
  if (stored) return stored;
  const newId = generateSessionId();
  sessionStorage.setItem('mageba_session_id', newId);
  return newId;
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<(CartItem & { product: Product })[]>([]);
  const [currency, setCurrency] = useState<Currency>(() => {
    const stored = localStorage.getItem('mageba_currency');
    return (stored as Currency) || 'USD';
  });
  const [loading, setLoading] = useState(true);
  const sessionId = getSessionId();

  useEffect(() => {
    localStorage.setItem('mageba_currency', currency);
  }, [currency]);

  const fetchCart = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select('*, product:products(*)')
        .eq('session_id', sessionId);

      if (error) throw error;
      setItems((data || []) as (CartItem & { product: Product })[]);
    } catch (err) {
      console.error('Error fetching cart:', err);
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    fetchCart();
  }, [fetchCart]);

  const addToCart = async (product: Product, quantity = 1) => {
    const existing = items.find(item => item.product_id === product.id);

    if (existing) {
      await updateQuantity(product.id, existing.quantity + quantity);
      return;
    }

    const { error } = await supabase
      .from('cart_items')
      .insert({ session_id: sessionId, product_id: product.id, quantity });

    if (!error) fetchCart();
  };

  const removeFromCart = async (productId: string) => {
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('session_id', sessionId)
      .eq('product_id', productId);

    if (!error) fetchCart();
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeFromCart(productId);
      return;
    }

    const { error } = await supabase
      .from('cart_items')
      .update({ quantity })
      .eq('session_id', sessionId)
      .eq('product_id', productId);

    if (!error) fetchCart();
  };

  const clearCart = async () => {
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('session_id', sessionId);

    if (!error) fetchCart();
  };

  const convertPrice = (priceUsd: number): number => {
    return priceUsd * EXCHANGE_RATES[currency];
  };

  const formatPrice = (priceUsd: number): string => {
    const converted = convertPrice(priceUsd);
    const symbol = CURRENCY_SYMBOLS_MAP[currency];

    if (currency === 'ZMW' || currency === 'BWP') {
      return `${symbol}${converted.toFixed(2)}`;
    }
    return `${symbol}${converted.toFixed(2)}`;
  };

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotalUsd = items.reduce((sum, item) => sum + (item.product?.price_usd || 0) * item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        currency,
        setCurrency,
        rates: EXCHANGE_RATES,
        loading,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        subtotalUsd,
        convertPrice,
        formatPrice,
        sessionId,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within CartProvider');
  return context;
}
