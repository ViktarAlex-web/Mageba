import { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Minus, Plus, ShoppingCart, MessageCircle, ShoppingBag } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../context/CartContext';
import type { Product } from '../types';

export function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [addingToCart, setAddingToCart] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);
  const { formatPrice, addToCart } = useCart();

  useEffect(() => {
    async function fetchProduct() {
      if (!slug) return;
      setLoading(true);
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('slug', slug)
        .maybeSingle();
      if (data) setProduct(data as Product);
      setLoading(false);
    }
    fetchProduct();
  }, [slug]);

  async function handleAddToCart() {
    if (!product) return;
    setAddingToCart(true);
    await addToCart(product, quantity);
    setAddingToCart(false);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2000);
  }

  function handleWhatsAppOrder() {
    if (!product) return;
    const message = encodeURIComponent(
      `Hi! I'm interested in ordering:\n\n` +
      `*${product.name}*\n` +
      `Condition: ${product.condition}\n` +
      `Price: ${formatPrice(product.price_usd)}\n` +
      `Quantity: ${quantity}\n` +
      `Subtotal: ${formatPrice(product.price_usd * quantity)}\n\n` +
      `Please confirm availability and shipping details.`
    );
    window.open(`https://wa.me/8617815651586?text=${message}`, '_blank');
  }

  if (!loading && !product) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-stone-900 mb-4">Product not found</h1>
          <Link to="/products" className="text-amber-600 hover:text-amber-700 font-medium">
            Browse all products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-stone-600 hover:text-stone-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        {loading ? (
          <div className="animate-pulse">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-stone-200 rounded-xl aspect-square" />
              <div className="space-y-4">
                <div className="h-8 bg-stone-200 rounded w-1/4" />
                <div className="h-10 bg-stone-200 rounded w-3/4" />
                <div className="h-6 bg-stone-200 rounded w-1/2" />
              </div>
            </div>
          </div>
        ) : product ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            <div className="space-y-4">
              <div className="relative aspect-square bg-white rounded-xl overflow-hidden border border-stone-200">
                {product.image_urls.length > 0 ? (
                  <img
                    src={product.image_urls[selectedImageIndex]}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-stone-400">
                    No image available
                  </div>
                )}
                {product.condition === 'pre-owned' && (
                  <span className="absolute top-4 left-4 bg-stone-700 text-stone-100 text-sm px-3 py-1 rounded-lg font-medium">
                    Pre-Owned
                  </span>
                )}
              </div>
              {product.image_urls.length > 1 && (
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {product.image_urls.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                        selectedImageIndex === idx ? 'border-amber-500' : 'border-stone-200'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div>
                <Link
                  to={`/category/${product.category?.slug}`}
                  className="text-sm text-amber-600 hover:text-amber-700 font-medium"
                >
                  {product.category?.name}
                </Link>
                {product.brand && (
                  <span className="text-sm text-stone-500 ml-2">| {product.brand}</span>
                )}
              </div>

              <h1 className="text-2xl sm:text-3xl font-bold text-stone-900">{product.name}</h1>

              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-amber-600">{formatPrice(product.price_usd)}</span>
                <span className="text-sm text-stone-500">per item</span>
              </div>

              {product.description && (
                <div className="prose prose-stone max-w-none">
                  <p className="text-stone-600 leading-relaxed">{product.description}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-stone-500">Condition:</span>
                  <span className={`px-2 py-1 rounded ${product.condition === 'new' ? 'bg-green-100 text-green-800' : 'bg-stone-100 text-stone-700'}`}>
                    {product.condition === 'new' ? 'Brand New' : 'Pre-Owned'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-stone-500">Stock:</span>
                  <span className={product.stock_quantity > 0 ? 'text-green-600' : 'text-red-600'}>
                    {product.stock_quantity > 0 ? `${product.stock_quantity} available` : 'Out of Stock'}
                  </span>
                </div>
              </div>

              {product.stock_quantity > 0 && (
                <div className="border-t border-stone-200 pt-6 space-y-6">
                  <div className="flex items-center gap-4">
                    <span className="text-stone-600 font-medium">Quantity:</span>
                    <div className="flex items-center border border-stone-300 rounded-lg">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="p-3 hover:bg-stone-100 transition-colors"
                        disabled={quantity <= 1}
                      >
                        <Minus className="w-4 h-4 text-stone-600" />
                      </button>
                      <span className="px-6 py-2 text-stone-900 font-medium min-w-[60px] text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
                        className="p-3 hover:bg-stone-100 transition-colors"
                        disabled={quantity >= product.stock_quantity}
                      >
                        <Plus className="w-4 h-4 text-stone-600" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-stone-100 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <span className="text-stone-600">Subtotal:</span>
                      <span className="text-xl font-bold text-stone-900">{formatPrice(product.price_usd * quantity)}</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <button
                      onClick={handleAddToCart}
                      disabled={addingToCart || product.stock_quantity === 0}
                      className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 rounded-lg font-semibold transition-all ${
                        addedSuccess
                          ? 'bg-green-500 text-white'
                          : 'bg-stone-900 hover:bg-stone-800 text-white'
                      }`}
                    >
                      {addingToCart ? (
                        'Adding...'
                      ) : addedSuccess ? (
                        <>
                          <ShoppingBag className="w-5 h-5" />
                          Added to Cart!
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="w-5 h-5" />
                          Add to Cart
                        </>
                      )}
                    </button>
                    <button
                      onClick={handleWhatsAppOrder}
                      className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-4 rounded-lg font-semibold transition-colors"
                    >
                      <MessageCircle className="w-5 h-5" />
                      Order on WhatsApp
                    </button>
                  </div>
                </div>
              )}

              <div className="bg-stone-900 rounded-lg p-6 text-stone-100">
                <h3 className="font-semibold mb-3">Shipping Information</h3>
                <ul className="text-sm text-stone-300 space-y-2">
                  <li>Ships from China</li>
                  <li>Delivers to: Zimbabwe, South Africa, Zambia, Botswana</li>
                  <li>Contact us for shipping rates and delivery times</li>
                </ul>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
