import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../context/CartContext';
import type { Product, Category } from '../types';

export function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [category, setCategory] = useState<Category | null>(null);
  const [loading, setLoading] = useState(true);
  const { formatPrice } = useCart();

  useEffect(() => {
    async function fetchData() {
      if (!slug) return;
      setLoading(true);

      const { data: catData } = await supabase
        .from('categories')
        .select('*')
        .eq('slug', slug)
        .maybeSingle();

      if (catData) {
        setCategory(catData as Category);
        const { data: prodData } = await supabase
          .from('products')
          .select('*, category:categories(*)')
          .eq('category_id', catData.id);

        if (prodData) setProducts(prodData as Product[]);
      }
      setLoading(false);
    }
    fetchData();
  }, [slug]);

  if (!loading && !category) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-stone-900 mb-4">Category not found</h1>
          <Link to="/products" className="text-amber-600 hover:text-amber-700 font-medium">
            Browse all products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50">
      <div className="bg-stone-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/products" className="inline-flex items-center gap-2 text-stone-400 hover:text-stone-100 mb-4 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            All Products
          </Link>
          <h1 className="text-3xl sm:text-4xl font-bold text-stone-100">
            {loading ? 'Loading...' : category?.name}
          </h1>
          {category?.description && (
            <p className="text-stone-400 mt-2">{category.description}</p>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse bg-white rounded-xl p-4">
                <div className="bg-stone-200 rounded-lg aspect-square mb-4" />
                <div className="h-4 bg-stone-200 rounded w-3/4 mb-2" />
                <div className="h-4 bg-stone-200 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-stone-500 mb-4">No products available in this category.</p>
            <Link to="/products" className="text-amber-600 hover:text-amber-700 font-medium">
              Browse all products
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <Link
                key={product.id}
                to={`/product/${product.slug}`}
                className="group bg-white rounded-xl border border-stone-200 overflow-hidden hover:shadow-xl hover:border-amber-300 transition-all duration-300"
              >
                <div className="relative aspect-square bg-stone-100 overflow-hidden">
                  {product.image_urls[0] ? (
                    <img
                      src={product.image_urls[0]}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-stone-400">
                      No Image
                    </div>
                  )}
                  {product.condition === 'pre-owned' && (
                    <span className="absolute top-3 left-3 bg-stone-700 text-stone-100 text-xs px-2 py-1 rounded">
                      Pre-Owned
                    </span>
                  )}
                </div>
                <div className="p-4">
                  <p className="text-xs text-stone-500 mb-1">{product.brand}</p>
                  <h3 className="font-medium text-stone-900 mb-2 line-clamp-2 group-hover:text-amber-600 transition-colors">
                    {product.name}
                  </h3>
                  <span className="text-lg font-bold text-amber-600">{formatPrice(product.price_usd)}</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
