import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, LayoutGrid, List, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../context/CartContext';
import type { Product, Category } from '../types';

export function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchParams, setSearchParams] = useSearchParams();
  const { formatPrice } = useCart();

  const selectedCategory = searchParams.get('category') || '';
  const selectedBrand = searchParams.get('brand') || '';
  const selectedCondition = searchParams.get('condition') || '';
  const sortBy = searchParams.get('sort') || 'name';
  const search = searchParams.get('search') || '';

  const brands = ['Apple', 'Samsung', 'Google', 'Crocs', 'Coach', 'Chanel', 'Mageba Baby'];

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      const [productsRes, categoriesRes] = await Promise.all([
        supabase.from('products').select('*, category:categories(*)'),
        supabase.from('categories').select('*').order('name'),
      ]);

      if (productsRes.data) setProducts(productsRes.data as Product[]);
      if (categoriesRes.data) setCategories(categoriesRes.data as Category[]);
      setLoading(false);
    }
    fetchData();
  }, []);

  const filteredProducts = products
    .filter(p => !selectedCategory || p.category?.slug === selectedCategory)
    .filter(p => !selectedBrand || p.brand === selectedBrand)
    .filter(p => !selectedCondition || p.condition === selectedCondition)
    .filter(p => !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.description?.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low': return a.price_usd - b.price_usd;
        case 'price-high': return b.price_usd - a.price_usd;
        case 'newest': return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        default: return a.name.localeCompare(b.name);
      }
    });

  function updateFilter(key: string, value: string) {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    setSearchParams(params);
  }

  function clearFilters() {
    setSearchParams({});
  }

  const hasActiveFilters = selectedCategory || selectedBrand || selectedCondition || search;

  const categoryTitle = selectedCategory
    ? categories.find(c => c.slug === selectedCategory)?.name || 'Products'
    : 'All Products';

  return (
    <div className="min-h-screen bg-stone-50">
      <div className="bg-stone-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-stone-100">{categoryTitle}</h1>
          <p className="text-stone-400 mt-2">
            {loading ? 'Loading...' : `${filteredProducts.length} products found`}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <aside className="lg:w-64 flex-shrink-0">
            <div className="lg:hidden mb-4">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-stone-200 rounded-lg text-stone-700 font-medium"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filters
                {hasActiveFilters && (
                  <span className="bg-amber-500 text-white text-xs rounded-full px-2 py-0.5">
                    {[selectedCategory, selectedBrand, selectedCondition, search].filter(Boolean).length}
                  </span>
                )}
              </button>
            </div>

            <div className={`${showFilters ? 'block' : 'hidden'} lg:block bg-white rounded-xl p-6 shadow-sm border border-stone-200`}>
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-semibold text-stone-900">Filters</h3>
                {hasActiveFilters && (
                  <button onClick={clearFilters} className="text-sm text-amber-600 hover:text-amber-700">
                    Clear All
                  </button>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-stone-700 mb-2">Search</label>
                <input
                  type="text"
                  value={search}
                  onChange={(e) => updateFilter('search', e.target.value)}
                  placeholder="Search products..."
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                />
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-stone-700 mb-2">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => updateFilter('category', e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                >
                  <option value="">All Categories</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.slug}>{cat.name}</option>
                  ))}
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-stone-700 mb-2">Brand</label>
                <select
                  value={selectedBrand}
                  onChange={(e) => updateFilter('brand', e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                >
                  <option value="">All Brands</option>
                  {brands.map(brand => (
                    <option key={brand} value={brand}>{brand}</option>
                  ))}
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-stone-700 mb-2">Condition</label>
                <select
                  value={selectedCondition}
                  onChange={(e) => updateFilter('condition', e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                >
                  <option value="">All Conditions</option>
                  <option value="new">New</option>
                  <option value="pre-owned">Pre-Owned</option>
                </select>
              </div>
            </div>
          </aside>

          <div className="flex-1">
            <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
              <div className="flex items-center gap-2">
                <span className="text-sm text-stone-600">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => updateFilter('sort', e.target.value)}
                  className="px-3 py-2 border border-stone-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500"
                >
                  <option value="name">Name</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="newest">Newest First</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-amber-100 text-amber-700' : 'bg-white text-stone-500'}`}
                >
                  <LayoutGrid className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-amber-100 text-amber-700' : 'bg-white text-stone-500'}`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>

            {hasActiveFilters && (
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedCategory && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm">
                    {categories.find(c => c.slug === selectedCategory)?.name}
                    <button onClick={() => updateFilter('category', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {selectedBrand && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm">
                    {selectedBrand}
                    <button onClick={() => updateFilter('brand', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {selectedCondition && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm">
                    {selectedCondition}
                    <button onClick={() => updateFilter('condition', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {search && (
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm">
                    "{search}"
                    <button onClick={() => updateFilter('search', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
              </div>
            )}

            {loading ? (
              <div className={viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-white rounded-xl p-4">
                    <div className="bg-stone-200 rounded-lg aspect-square mb-4" />
                    <div className="h-4 bg-stone-200 rounded w-3/4 mb-2" />
                    <div className="h-4 bg-stone-200 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-stone-500 mb-4">No products match your filters.</p>
                <button onClick={clearFilters} className="text-amber-600 hover:text-amber-700 font-medium">
                  Clear all filters
                </button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <Link
                    key={product.id}
                    to={`/product/${product.slug}`}
                    className="group bg-white rounded-xl border border-stone-200 overflow-hidden hover:shadow-xl hover:border-amber-300 transition-all duration-300"
                  >
                    <div className="relative aspect-square bg-stone-100 overflow-hidden">
                      {product.image_urls[0] ? (
                        <img
                          src={product.image_urls[0]}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-stone-400">
                          No Image
                        </div>
                      )}
                      {product.condition === 'pre-owned' && (
                        <span className="absolute top-3 left-3 bg-stone-700 text-stone-100 text-xs px-2 py-1 rounded">
                          Pre-Owned
                        </span>
                      )}
                      {product.stock_quantity < 5 && product.stock_quantity > 0 && (
                        <span className="absolute top-3 right-3 bg-red-500 text-white text-xs px-2 py-1 rounded">
                          Low Stock
                        </span>
                      )}
                    </div>
                    <div className="p-4">
                      <p className="text-xs text-stone-500 mb-1">{product.brand || product.category?.name}</p>
                      <h3 className="font-medium text-stone-900 mb-2 line-clamp-2 group-hover:text-amber-600 transition-colors">
                        {product.name}
                      </h3>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-amber-600">{formatPrice(product.price_usd)}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredProducts.map((product) => (
                  <Link
                    key={product.id}
                    to={`/product/${product.slug}`}
                    className="group flex gap-6 bg-white rounded-xl border border-stone-200 p-4 hover:shadow-xl hover:border-amber-300 transition-all duration-300"
                  >
                    <div className="w-32 h-32 flex-shrink-0 bg-stone-100 rounded-lg overflow-hidden">
                      {product.image_urls[0] ? (
                        <img
                          src={product.image_urls[0]}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-stone-400">
                          No Image
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-stone-500 mb-1">{product.brand || product.category?.name}</p>
                      <h3 className="font-medium text-stone-900 mb-2 group-hover:text-amber-600 transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-sm text-stone-600 line-clamp-2 mb-2">{product.description}</p>
                      <div className="flex items-center gap-4">
                        <span className="text-lg font-bold text-amber-600">{formatPrice(product.price_usd)}</span>
                        {product.condition === 'pre-owned' && (
                          <span className="text-xs bg-stone-700 text-stone-100 px-2 py-1 rounded">Pre-Owned</span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
