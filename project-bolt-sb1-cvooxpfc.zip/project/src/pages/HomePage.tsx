import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck, Shield, Headphones } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useCart } from '../context/CartContext';
import type { Product, Category } from '../types';

export function HomePage() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const { formatPrice } = useCart();

  useEffect(() => {
    async function fetchData() {
      const [productsRes, categoriesRes] = await Promise.all([
        supabase.from('products').select('*, category:categories(*)').eq('featured', true).limit(8),
        supabase.from('categories').select('*').order('name'),
      ]);

      if (productsRes.data) setFeaturedProducts(productsRes.data as Product[]);
      if (categoriesRes.data) setCategories(categoriesRes.data as Category[]);
      setLoading(false);
    }
    fetchData();
  }, []);

  return (
    <div>
      <section className="relative bg-gradient-to-br from-stone-900 via-stone-800 to-stone-900 min-h-[80vh] flex items-center">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/4226140/pexels-photo-4226140.jpeg?auto=compress&cs=tinysrgb&w=1920')] bg-cover bg-center opacity-20" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-3xl">
            <span className="inline-block bg-amber-500/20 text-amber-400 px-4 py-2 rounded-full text-sm font-medium mb-6">
              Premium Quality Products from China
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-stone-100 leading-tight mb-6">
              Zulu Makes It{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-amber-600">
                Easy For You
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-stone-300 mb-8 leading-relaxed">
              Discover our curated selection of Crocs, iPhones, Android phones, baby clothes, and designer handbags. Ships to Zimbabwe, South Africa, Zambia, and Botswana.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                Shop Now
                <ArrowRight className="w-5 h-5" />
              </Link>
              <a
                href="https://wa.me/8617815651586"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300"
              >
                Order on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-stone-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="w-8 h-8 text-amber-500" />
              </div>
              <h3 className="text-stone-100 font-semibold text-lg mb-2">Fast Shipping</h3>
              <p className="text-stone-400 text-sm">Direct from China to your doorstep</p>
            </div>
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-amber-500" />
              </div>
              <h3 className="text-stone-100 font-semibold text-lg mb-2">Quality Assured</h3>
              <p className="text-stone-400 text-sm">All products inspected and verified</p>
            </div>
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Headphones className="w-8 h-8 text-amber-500" />
              </div>
              <h3 className="text-stone-100 font-semibold text-lg mb-2">24/7 Support</h3>
              <p className="text-stone-400 text-sm">WhatsApp ordering and support</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-stone-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-10">
            <div>
              <h2 className="text-3xl font-bold text-stone-900">Shop by Category</h2>
              <p className="text-stone-600 mt-2">Find exactly what you're looking for</p>
            </div>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse bg-stone-200 rounded-xl aspect-square" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  to={`/category/${category.slug}`}
                  className="group relative rounded-xl overflow-hidden aspect-square"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-600 to-amber-800" />
                  <div className="absolute inset-0 bg-stone-900/40 group-hover:bg-stone-900/20 transition-colors" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
                    <h3 className="text-white font-semibold text-lg">{category.name}</h3>
                    <span className="text-amber-200 text-sm mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      Shop Now
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-10">
            <div>
              <h2 className="text-3xl font-bold text-stone-900">Featured Products</h2>
              <p className="text-stone-600 mt-2">Hand-picked selection of our best items</p>
            </div>
            <Link
              to="/products"
              className="hidden sm:inline-flex items-center gap-2 text-amber-600 hover:text-amber-700 font-semibold"
            >
              View All
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-stone-200 rounded-xl aspect-square mb-4" />
                  <div className="h-4 bg-stone-200 rounded w-3/4 mb-2" />
                  <div className="h-4 bg-stone-200 rounded w-1/2" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <Link
                  key={product.id}
                  to={`/product/${product.slug}`}
                  className="group bg-white rounded-xl border border-stone-200 overflow-hidden hover:shadow-xl hover:border-amber-300 transition-all duration-300"
                >
                  <div className="relative aspect-square bg-stone-100 overflow-hidden">
                    {product.image_urls[0] ? (
                      <img
                        src={product.image_urls[0]}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-stone-400">
                        No Image
                      </div>
                    )}
                    {product.condition === 'pre-owned' && (
                      <span className="absolute top-3 left-3 bg-stone-700 text-stone-100 text-xs px-2 py-1 rounded">
                        Pre-Owned
                      </span>
                    )}
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-stone-500 mb-1">{product.brand || product.category?.name}</p>
                    <h3 className="font-medium text-stone-900 mb-2 line-clamp-2 group-hover:text-amber-600 transition-colors">
                      {product.name}
                    </h3>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-amber-600">{formatPrice(product.price_usd)}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <Link
              to="/products"
              className="inline-flex items-center gap-2 text-amber-600 hover:text-amber-700 font-semibold"
            >
              View All Products
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-amber-600 to-amber-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Ready to Shop?
          </h2>
          <p className="text-amber-100 text-lg mb-8 max-w-2xl mx-auto">
            Browse our premium collection and place your order via WhatsApp. We ship to Zimbabwe, South Africa, Zambia, and Botswana.
          </p>
          <a
            href="https://wa.me/8617815651586"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-white text-amber-700 px-8 py-4 rounded-lg font-bold text-lg hover:bg-stone-100 transition-colors shadow-lg"
          >
            Contact Us on WhatsApp
            <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </section>
    </div>
  );
}
