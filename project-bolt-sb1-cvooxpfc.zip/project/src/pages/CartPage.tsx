import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Minus, Plus, ShoppingBag, ArrowRight, MessageCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';

export function CartPage() {
  const {
    items,
    loading,
    formatPrice,
    subtotalUsd,
    updateQuantity,
    removeFromCart,
    clearCart,
  } = useCart();
  const [checkingOut] = useState(false);

  function handleWhatsAppCheckout() {
    if (items.length === 0) return;

    const orderDetails = items
      .map(
        (item) =>
          `• ${item.product.name} (x${item.quantity}) - ${formatPrice(item.product.price_usd * item.quantity)}`
      )
      .join('\n');

    const message = encodeURIComponent(
      `Hi! I'd like to place an order:\n\n${orderDetails}\n\n` +
      `*Total: ${formatPrice(subtotalUsd)}*\n\n` +
      `Please provide shipping details and payment information.`
    );

    window.open(`https://wa.me/8617815651586?text=${message}`, '_blank');
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-stone-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-6">
            <div className="h-10 bg-stone-200 rounded w-48" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="col-span-2 space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-32 bg-stone-200 rounded-xl" />
                ))}
              </div>
              <div className="h-64 bg-stone-200 rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-stone-900 mb-8">Shopping Cart</h1>

        {items.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl border border-stone-200">
            <ShoppingBag className="w-16 h-16 text-stone-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-stone-900 mb-2">Your cart is empty</h2>
            <p className="text-stone-500 mb-6">Add some products to get started!</p>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Browse Products
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-xl border border-stone-200 p-4 sm:p-6 flex gap-4 sm:gap-6"
                >
                  <div className="w-24 h-24 sm:w-32 sm:h-32 flex-shrink-0 bg-stone-100 rounded-lg overflow-hidden">
                    {item.product.image_urls[0] ? (
                      <img
                        src={item.product.image_urls[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-stone-400 text-sm">
                        No Image
                      </div>
                    )}
                  </div>
                  <div className="flex-1 flex flex-col">
                    <div className="flex-1">
                      <Link
                        to={`/product/${item.product.slug}`}
                        className="font-medium text-stone-900 hover:text-amber-600 line-clamp-2"
                      >
                        {item.product.name}
                      </Link>
                      <p className="text-sm text-stone-500 mt-1">
                        {item.product.brand || 'No brand'}
                      </p>
                      <p className="text-amber-600 font-semibold mt-1">
                        {formatPrice(item.product.price_usd)} each
                      </p>
                    </div>
                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center border border-stone-300 rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="p-2 hover:bg-stone-100 transition-colors rounded-l-lg"
                        >
                          <Minus className="w-4 h-4 text-stone-600" />
                        </button>
                        <span className="px-4 py-1 text-stone-900 font-medium min-w-[40px] text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className="p-2 hover:bg-stone-100 transition-colors rounded-r-lg"
                        >
                          <Plus className="w-4 h-4 text-stone-600" />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="p-2 text-stone-400 hover:text-red-500 transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              <div className="flex justify-between items-center pt-4">
                <Link
                  to="/products"
                  className="text-amber-600 hover:text-amber-700 font-medium"
                >
                  Continue Shopping
                </Link>
                <button
                  onClick={clearCart}
                  className="text-sm text-stone-500 hover:text-red-500 transition-colors"
                >
                  Clear Cart
                </button>
              </div>
            </div>

            <div className="lg:sticky lg:top-24 h-fit">
              <div className="bg-white rounded-xl border border-stone-200 p-6">
                <h2 className="text-lg font-semibold text-stone-900 mb-6">Order Summary</h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span className="text-stone-600">Subtotal ({items.length} items)</span>
                    <span className="text-stone-900 font-medium">{formatPrice(subtotalUsd)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-600">Shipping</span>
                    <span className="text-stone-500 text-sm">Calculated at checkout</span>
                  </div>
                </div>

                <div className="border-t border-stone-200 pt-4 mb-6">
                  <div className="flex justify-between">
                    <span className="text-stone-900 font-semibold">Total</span>
                    <span className="text-xl font-bold text-amber-600">{formatPrice(subtotalUsd)}</span>
                  </div>
                </div>

                <button
                  onClick={handleWhatsAppCheckout}
                  disabled={checkingOut}
                  className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-4 rounded-lg font-semibold transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  Checkout via WhatsApp
                </button>

                <p className="text-xs text-stone-500 text-center mt-4">
                  Complete your order by contacting us on WhatsApp with your cart details.
                </p>

                <div className="mt-6 pt-6 border-t border-stone-200">
                  <h3 className="text-sm font-medium text-stone-900 mb-3">We Ship To:</h3>
                  <div className="flex flex-wrap gap-2">
                    <span className="inline-block bg-stone-100 text-stone-600 text-xs px-3 py-1 rounded-full">Zimbabwe</span>
                    <span className="inline-block bg-stone-100 text-stone-600 text-xs px-3 py-1 rounded-full">South Africa</span>
                    <span className="inline-block bg-stone-100 text-stone-600 text-xs px-3 py-1 rounded-full">Zambia</span>
                    <span className="inline-block bg-stone-100 text-stone-600 text-xs px-3 py-1 rounded-full">Botswana</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
