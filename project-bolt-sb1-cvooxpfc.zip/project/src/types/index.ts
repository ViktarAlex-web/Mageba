export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  price_usd: number;
  category_id: string | null;
  image_urls: string[];
  brand: string | null;
  condition: string;
  stock_quantity: number;
  featured: boolean;
  created_at: string;
  category?: Category;
}

export interface CartItem {
  id: string;
  session_id: string;
  product_id: string;
  quantity: number;
  created_at: string;
  product?: Product;
}

export type Currency = 'USD' | 'ZAR' | 'ZMW' | 'BWP';

export interface ExchangeRates {
  USD: number;
  ZAR: number;
  ZMW: number;
  BWP: number;
}

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: '$',
  ZAR: 'R',
  ZMW: 'K',
  BWP: 'P',
};

export const CURRENCY_NAMES: Record<Currency, string> = {
  USD: 'US Dollar',
  ZAR: 'South African Rand',
  ZMW: 'Zambian Kwacha',
  BWP: 'Botswana Pula',
};

export const SHIPPING_DESTINATIONS = [
  { code: 'ZW', name: 'Zimbabwe' },
  { code: 'ZA', name: 'South Africa' },
  { code: 'ZM', name: 'Zambia' },
  { code: 'BW', name: 'Botswana' },
];
