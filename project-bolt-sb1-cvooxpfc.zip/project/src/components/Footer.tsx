import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-stone-900 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-gradient-to-br from-amber-600 to-amber-800 rounded-lg p-2">
                <span className="text-white font-bold text-xl">M</span>
              </div>
              <div>
                <h3 className="text-stone-100 font-bold text-lg">Mageba Imports</h3>
                <p className="text-amber-500 text-xs">Zulu makes it easy for you</p>
              </div>
            </div>
            <p className="text-stone-400 text-sm leading-relaxed">
              Premium quality products shipped directly from China to Zimbabwe, South Africa, Zambia, and Botswana.
            </p>
          </div>

          <div>
            <h4 className="text-stone-100 font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-stone-400 hover:text-amber-500 text-sm transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-stone-400 hover:text-amber-500 text-sm transition-colors">
                  All Products
                </Link>
              </li>
              <li>
                <Link to="/category/crocs" className="text-stone-400 hover:text-amber-500 text-sm transition-colors">
                  Crocs
                </Link>
              </li>
              <li>
                <Link to="/category/iphones" className="text-stone-400 hover:text-amber-500 text-sm transition-colors">
                  iPhones
                </Link>
              </li>
              <li>
                <Link to="/category/designer-handbags" className="text-stone-400 hover:text-amber-500 text-sm transition-colors">
                  Designer Handbags
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-stone-100 font-semibold mb-4">Shipping Destinations</h4>
            <ul className="space-y-2 text-stone-400 text-sm">
              <li className="flex items-center gap-2">
                <MapPin className="w-3 h-3 text-amber-500" />
                Zimbabwe
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3 h-3 text-amber-500" />
                South Africa
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3 h-3 text-amber-500" />
                Zambia
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-3 h-3 text-amber-500" />
                Botswana
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-stone-100 font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="https://wa.me/8617815651586"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-stone-400 hover:text-amber-500 text-sm transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  +86 178 156 51586
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@magebaimports.com"
                  className="flex items-center gap-2 text-stone-400 hover:text-amber-500 text-sm transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  info@magebaimports.com
                </a>
              </li>
            </ul>
            <div className="flex gap-4 mt-4">
              <a
                href="#"
                className="text-stone-400 hover:text-amber-500 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-stone-400 hover:text-amber-500 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-stone-400 hover:text-amber-500 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-stone-800 mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-stone-500 text-sm">
            © {new Date().getFullYear()} Mageba Imports. All rights reserved.
          </p>
          <div className="flex gap-6 text-stone-400 text-sm">
            <span className="flex items-center gap-1">
              Payments: USD | ZAR | ZMW | BWP
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
