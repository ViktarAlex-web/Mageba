import { useCart } from '../context/CartContext';
import type { Currency } from '../types';

export function CurrencySelector() {
  const { currency, setCurrency } = useCart();

  return (
    <select
      value={currency}
      onChange={(e) => setCurrency(e.target.value as Currency)}
      className="bg-transparent border border-stone-600 text-stone-100 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
    >
      <option value="USD" className="bg-stone-800 text-stone-100">USD</option>
      <option value="ZAR" className="bg-stone-800 text-stone-100">ZAR</option>
      <option value="ZMW" className="bg-stone-800 text-stone-100">ZMW</option>
      <option value="BWP" className="bg-stone-800 text-stone-100">BWP</option>
    </select>
  );
}
