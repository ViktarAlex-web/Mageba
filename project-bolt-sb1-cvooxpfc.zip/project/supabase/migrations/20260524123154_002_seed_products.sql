/*
  # Seed Categories and Products

  This migration populates the database with initial product data for Mageba Imports.

  Categories:
    - Crocs
    - iPhones (new & pre-owned)
    - Android Phones
    - Baby Clothes
    - Designer Handbags (Coach, Chanel)

  Sample products added for each category with realistic pricing in USD.
*/

-- Insert categories
INSERT INTO categories (name, slug, description, image_url) VALUES
  ('Crocs', 'crocs', 'Comfortable and stylish Crocs footwear for all ages', 'https://images.pexels.com/photos/267301/pexels-photo-267301.jpeg?auto=compress&cs=tinysrgb&w=600'),
  ('iPhones', 'iphones', 'Apple iPhones - brand new and pre-owned options available', 'https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'),
  ('Android Phones', 'android-phones', 'Quality Android smartphones from top brands', 'https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'),
  ('Baby Clothes', 'baby-clothes', 'Adorable and comfortable clothing for your little ones', 'https://images.pexels.com/photos/921955/pexels-photo-921955.jpeg?auto=compress&cs=tinysrgb&w=600'),
  ('Designer Handbags', 'designer-handbags', 'Luxury handbags from Coach, Chanel and more', 'https://images.pexels.com/catalogs/pexels-photo-90789.jpeg?auto=compress&cs=tinysrgb&w=600')
ON CONFLICT (slug) DO NOTHING;

-- Insert Crocs products
INSERT INTO products (name, slug, description, price_usd, category_id, image_urls, brand, condition, stock_quantity, featured) VALUES
  ('Classic Clog - Black', 'classic-clog-black', 'The original Crocs Classic Clog in timeless black. Comfortable, lightweight, and perfect for everyday wear.', 49.99, (SELECT id FROM categories WHERE slug = 'crocs'), ARRAY['https://images.pexels.com/photos/267301/pexels-photo-267301.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Crocs', 'new', 50, true),
  ('Classic Clog - White', 'classic-clog-white', 'Classic white Crocs Clog for a clean, fresh look. Easy to clean and maintain.', 49.99, (SELECT id FROM categories WHERE slug = 'crocs'), ARRAY['https://images.pexels.com/photos/267301/pexels-photo-267301.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Crocs', 'new', 45, false),
  ('Platform Clog - Beige', 'platform-clog-beige', 'Elevated style with the Platform Clog in elegant beige. Extra height with all-day comfort.', 69.99, (SELECT id FROM categories WHERE slug = 'crocs'), ARRAY['https://images.pexels.com/photos/267301/pexels-photo-267301.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Crocs', 'new', 30, true),
  ('LiteRide Pacer - Navy', 'literide-pacer-navy', 'Sporty LiteRide Pacer in navy blue. Revolutionary foam technology for superior comfort.', 79.99, (SELECT id FROM categories WHERE slug = 'crocs'), ARRAY['https://images.pexels.com/photos/267301/pexels-photo-267301.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Crocs', 'new', 25, false)
ON CONFLICT (slug) DO NOTHING;

-- Insert iPhone products
INSERT INTO products (name, slug, description, price_usd, category_id, image_urls, brand, condition, stock_quantity, featured) VALUES
  ('iPhone 15 Pro Max 256GB - Natural Titanium', 'iphone-15-pro-max-256-natural', 'Brand new iPhone 15 Pro Max in stunning Natural Titanium. A17 Pro chip, 5x optical zoom camera system.', 1199.99, (SELECT id FROM categories WHERE slug = 'iphones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Apple', 'new', 15, true),
  ('iPhone 15 Pro 128GB - Blue Titanium', 'iphone-15-pro-128-blue', 'New iPhone 15 Pro in Blue Titanium. Pro-grade camera, titanium design, and A17 Pro chip.', 999.99, (SELECT id FROM categories WHERE slug = 'iphones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Apple', 'new', 20, true),
  ('iPhone 14 Pro 128GB - Deep Purple', 'iphone-14-pro-128-purple', 'Pre-owned iPhone 14 Pro in excellent condition. A16 Bionic chip, Dynamic Island, 48MP camera.', 749.99, (SELECT id FROM categories WHERE slug = 'iphones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Apple', 'pre-owned', 12, false),
  ('iPhone 13 128GB - Midnight', 'iphone-13-128-midnight', 'Pre-owned iPhone 13 in Midnight. Great condition, excellent battery life, A15 Bionic chip.', 499.99, (SELECT id FROM categories WHERE slug = 'iphones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Apple', 'pre-owned', 18, false),
  ('iPhone 12 64GB - Blue', 'iphone-12-64-blue', 'Pre-owned iPhone 12 in Blue. 5G capable, dual-camera system, A14 Bionic chip.', 349.99, (SELECT id FROM categories WHERE slug = 'iphones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Apple', 'pre-owned', 10, false)
ON CONFLICT (slug) DO NOTHING;

-- Insert Android Phone products
INSERT INTO products (name, slug, description, price_usd, category_id, image_urls, brand, condition, stock_quantity, featured) VALUES
  ('Samsung Galaxy S24 Ultra 256GB - Titanium Black', 'galaxy-s24-ultra-256-black', 'New Galaxy S24 Ultra with built-in S Pen, 200MP camera, and AI-powered features.', 1299.99, (SELECT id FROM categories WHERE slug = 'android-phones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Samsung', 'new', 12, true),
  ('Samsung Galaxy S24 128GB - Amber Yellow', 'galaxy-s24-128-yellow', 'New Samsung Galaxy S24 in vibrant Amber Yellow. AI-powered, stunning display.', 799.99, (SELECT id FROM categories WHERE slug = 'android-phones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Samsung', 'new', 18, false),
  ('Google Pixel 8 Pro 128GB - Obsidian', 'pixel-8-pro-128-obsidian', 'New Google Pixel 8 Pro in Obsidian. Best-in-class camera with AI photography features.', 999.99, (SELECT id FROM categories WHERE slug = 'android-phones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Google', 'new', 10, true),
  ('Samsung Galaxy A54 128GB - Awesome Violet', 'galaxy-a54-128-violet', 'New Galaxy A54 in Awesome Violet. Big screen, long battery life, great value.', 449.99, (SELECT id FROM categories WHERE slug = 'android-phones'), ARRAY['https://images.pexels.com/photos/607770/pexels-photo-607770.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Samsung', 'new', 25, false)
ON CONFLICT (slug) DO NOTHING;

-- Insert Baby Clothes products
INSERT INTO products (name, slug, description, price_usd, category_id, image_urls, brand, condition, stock_quantity, featured) VALUES
  ('Organic Cotton Onesie Set - 3 Pack', 'organic-onesie-set-3pack', 'Soft organic cotton onesies in white, grey, and beige. Perfect for newborns 0-3 months.', 34.99, (SELECT id FROM categories WHERE slug = 'baby-clothes'), ARRAY['https://images.pexels.com/photos/921955/pexels-photo-921955.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Mageba Baby', 'new', 40, true),
  ('Knitted Cardigan - Cream', 'knitted-cardigan-cream', 'Adorable knitted cardigan in cream. Soft and warm for cooler days.', 39.99, (SELECT id FROM categories WHERE slug = 'baby-clothes'), ARRAY['https://images.pexels.com/photos/921955/pexels-photo-921955.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Mageba Baby', 'new', 25, false),
  ('Floral Print Dress - Pink', 'floral-dress-pink', 'Beautiful floral print dress in soft pink. Perfect for special occasions.', 29.99, (SELECT id FROM categories WHERE slug = 'baby-clothes'), ARRAY['https://images.pexels.com/photos/921955/pexels-photo-921955.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Mageba Baby', 'new', 30, false),
  ('Dinosaur Pajama Set - Green', 'dinosaur-pajama-green', 'Fun dinosaur print pajama set in green. Cozy and cute for bedtime.', 26.99, (SELECT id FROM categories WHERE slug = 'baby-clothes'), ARRAY['https://images.pexels.com/photos/921955/pexels-photo-921955.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Mageba Baby', 'new', 35, false),
  ('Winter Romper with Hood - Brown', 'winter-romper-brown', 'Warm winter romper with hood in brown. Fleece-lined for extra coziness.', 44.99, (SELECT id FROM categories WHERE slug = 'baby-clothes'), ARRAY['https://images.pexels.com/photos/921955/pexels-photo-921955.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Mageba Baby', 'new', 20, true)
ON CONFLICT (slug) DO NOTHING;

-- Insert Designer Handbag products
INSERT INTO products (name, slug, description, price_usd, category_id, image_urls, brand, condition, stock_quantity, featured) VALUES
  ('Coach Tabby Shoulder Bag 26 - Beige', 'coach-tabby-shoulder-26-beige', 'Authentic Coach Tabby Shoulder Bag in beige. Signature canvas with leather trim.', 495.00, (SELECT id FROM categories WHERE slug = 'designer-handbags'), ARRAY['https://images.pexels.com/photos/90789/pexels-photo-90789.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Coach', 'new', 8, true),
  ('Coach Peyton Carryall - Brown', 'coach-peyton-carryall-brown', 'Elegant Coach Peyton Carryall in brown. Spacious and sophisticated for everyday use.', 650.00, (SELECT id FROM categories WHERE slug = 'designer-handbags'), ARRAY['https://images.pexels.com/photos/90789/pexels-photo-90789.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Coach', 'new', 5, false),
  ('Chanel Classic Flap Medium - Black', 'chanel-classic-flap-medium-black', 'Pre-owned Chanel Classic Flap in black caviar leather with gold hardware. Excellent condition.', 8950.00, (SELECT id FROM categories WHERE slug = 'designer-handbags'), ARRAY['https://images.pexels.com/photos/90789/pexels-photo-90789.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Chanel', 'pre-owned', 2, true),
  ('Chanel Boy Bag Small - Chocolate', 'chanel-boy-small-chocolate', 'Pre-owned Chanel Boy Bag in chocolate calfskin. Iconic design in excellent condition.', 5800.00, (SELECT id FROM categories WHERE slug = 'designer-handbags'), ARRAY['https://images.pexels.com/photos/90789/pexels-photo-90789.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Chanel', 'pre-owned', 3, false),
  ('Coach Willis Bag - Tan', 'coach-willis-tan', 'Classic Coach Willis Bag in tan. Timeless design with signature turnlock.', 425.00, (SELECT id FROM categories WHERE slug = 'designer-handbags'), ARRAY['https://images.pexels.com/photos/90789/pexels-photo-90789.jpeg?auto=compress&cs=tinysrgb&w=600'], 'Coach', 'new', 6, false)
ON CONFLICT (slug) DO NOTHING;